# Internal functions for SuperLearner package
# 
# Created by Eric Polley on 2011-01-03
# 

# .SL.require() extends the require() function to add my own error messages
.SL.require <- function(package, message = paste('loading required package (', package, ') failed', sep = '')) {
  if(!requireNamespace(package, quietly = FALSE)) {
    stop(message, call. = FALSE)
  }
  invisible(TRUE)
}

# .createLibrary()
# takes the input from SL.library and sets up the library for SuperLearner()
# SL.library may be a character vector or a list
# return list of prediction algorithms and list of screening algorithms.  If screening algorithms are used, must generate the whichScreen matrix and assign the appropriate row number to the prediction algorithm.  whichScreen[1, ] will always be the full data set, even if no screening algorithms are specified.
# If character vector, only prediction algorithms are allowed.
# for the list, the structure is:
# list(c("predAlg1", "screenAlg1", "screenAlg2", ...), c("predAlg2", "screenAlg1", ...), c("predAlg3"))
# the list contains character vectors, and the scructure of the character vectors is always prediction algorithm first, followed by a list of screening algorithms to be coupled with the prediction algorithm.  If no screening algorithm is given (as in "predAlg3" above) then the algorithm will run on the entire set of variables by default.

.createLibrary <- function(SL.library) {
	if (is.character(SL.library)) { 
		k <- length(SL.library)
		whichScreen <- matrix(1, nrow = 1, ncol = k)
		screenAlgorithm <- "All"
		library <- data.frame(predAlgorithm = SL.library, rowScreen = 1, stringsAsFactors=FALSE)
	} else if (is.list(SL.library)) {
		predNames <- sapply(SL.library, FUN = "[", 1)
		NumberScreen <- (sapply(SL.library, FUN = length) - 1)
		if (sum(NumberScreen == 0) > 0) {
			for(ii in which(NumberScreen == 0)) {
				SL.library[[ii]] <- c(SL.library[[ii]], "All")
				NumberScreen[ii] <- 1
			}
		}
		screenAlgorithmFull <- unlist(lapply(SL.library, FUN="[", -1))
		screenAlgorithm <- unique(screenAlgorithmFull)
		
		library <- data.frame(predAlgorithm = rep(predNames, times=NumberScreen), rowScreen = match(screenAlgorithmFull, screenAlgorithm), stringsAsFactors = FALSE)
	} else {
	  stop('format for SL.library is not recognized')
	}
	
	out <- list(library = library, screenAlgorithm = screenAlgorithm)
	return(out)
}

