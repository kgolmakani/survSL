# gbm3 Cox regression
# not on CRAN, might not include in main package
# https://github.com/gbm-developers/gbm3

# survSL.gbm3 <- function(Y, X, newX, obsWeights, id,
# 		n.trees = 1000, shrinkage = 0.01, interaction.depth = 3, n.minobsinnode = 10, bag.fraction = 0.5, cv.folds = 10, ...) {
#   requireNamespace('gbm3')
#   # should we add a check for version 2 or version 3?
#   ## switch with gbmt and gbmt_performance?
#   fit_gbm <- gbm3::gbm(Y ~ ., data = X, weights = obsWeights, obs.id = id, distribution = 'coxph',
#   			n.trees = n.trees,
# 			shrinkage = shrinkage,
# 			interaction.depth = interaction.depth,
# 			n.minobsinnode = n.minobsinnode,
# 			bag.fraction = bag.fraction,
# 			cv.folds = cv.folds,
# 			tied.times.method = 'efron')
# 	iter <- gbm3::gbm.perf(fit_gbm, method = 'cv', plot.it = FALSE)
#
#   # If we predict with the cv.glmnet object we can specify lambda using s
#   pred <- predict(fit_gbm, newdata = newX, n.trees = iter, type = "link")
#
#   fit <- list(object = fit_gbm, n.trees = iter)
#   class(fit) <- "survSL.gbm"
#
#   out <- list(pred = pred, fit = fit)
#   return(out)
# }
#
# predict.survSL.gbm3 <- function(object, newdata, ...) {
#   requireNamespace('gbm3')
#   pred <- predict(object$object, newdata = newdata, n.trees = object$n.trees, type = "link")
#   return(pred)
# }
