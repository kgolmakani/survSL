# gbm Cox regression

survSL.gbm <- function(Y, X, newX, obsWeights, id, 
		n.trees = 1000, shrinkage = 0.01, interaction.depth = 3, n.minobsinnode = 10, bag.fraction = 0.5, cv.folds = 10, ...) {
  requireNamespace('gbm')
  # should we add a check for version 2 or version 3?

  fit_gbm <- gbm::gbm(Y ~ ., data = X, weights = obsWeights, distribution = 'coxph', 
  			n.trees = n.trees,
			shrinkage = shrinkage,
			interaction.depth = interaction.depth,
			n.minobsinnode = n.minobsinnode,
			bag.fraction = bag.fraction,
			cv.folds = cv.folds)
	iter <- gbm::gbm.perf(fit_gbm, method = 'cv', plot.it = FALSE)

  # If we predict with the cv.glmnet object we can specify lambda using s
  pred <- predict(fit_gbm, newdata = newX, n.trees = iter, type = "link")

  fit <- list(object = fit_gbm, n.trees = iter)
  class(fit) <- "survSL.gbm"

  out <- list(pred = pred, fit = fit)
  return(out)
}

predict.survSL.gbm <- function(object, newdata, ...) {
  requireNamespace('gbm')
  pred <- predict(object$object, newdata = newdata, n.trees = object$n.trees, type = "link")
  return(pred)
}
