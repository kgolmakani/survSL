survSLNews <- function(...) {
	RShowDoc("NEWS", package = "survSL", ...)
}

