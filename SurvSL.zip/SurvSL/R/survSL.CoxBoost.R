# Cox model by likelihood based boosting

survSL.CoxBoost <- function(Y, X, newX, obsWeights, id,
	minstepno = 50, maxstepno = 200, start.penalty = 9*sum(Y[, 2] == 1), iter.max = 10, upper.margin = 0.05,
                      ...) {
  requireNamespace('CoxBoost')
  require('Matrix')  # Matrix function used inside CoxBoost, when CoxBoost is fixed to use Matrix::Matrix, can remove
  # X must be a matrix, should we use model.matrix or as.matrix
  # TODO: support sparse matrices.
  if (!is.matrix(X)) {
    X <- model.matrix(~ -1 + ., X)
    newX <- model.matrix(~ -1 + ., newX)
  }

  # Use CV to find optimal parameters.
  optimal.penalty = CoxBoost::optimCoxBoostPenalty(time = time_Surv(Y), 
                                         status = event_Surv(Y),
										 x = X,
                                         minstepno = minstepno, 
										 maxstepno = maxstepno,
										 start.penalty = start.penalty,
										 iter.max = iter.max,
                                         upper.margin = upper.margin)
  fit <- CoxBoost::CoxBoost(time = time_Surv(Y),
	  status = event_Surv(Y),
	  x = X,
	  standardize = TRUE,
	  penalty = optimal.penalty$penalty,
	  stepno = optimal.penalty$cv.res$optimal.step,
                             ...)
  #
  pred <- as.numeric(predict(fit, newdata = newX, type = "lp")) # default predict method returns a matrix

  fit <- list(object = fit)
  class(fit) <- "survSL.glmboost"

  out <- list(pred = pred, fit = fit)
  return(out)
}

predict.survSL.CoxBoost <- function(object, newdata, ...) {
  requireNamespace('CoxBoost')
  # TODO: support sparse matrices.
  # if fit with a matrix, must predict with a matrix as well
  # should add a check for the columns matching, will breask if factor variables with different levels
  if (!is.matrix(newdata)) {
    newdata <- model.matrix(~ -1 + ., newdata)
  }
  pred <- as.numeric(predict(object$object, newdata = newdata, type = "lp"))
  return(pred)
}
