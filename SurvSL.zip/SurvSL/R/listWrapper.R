listWrappers <- function(what = "both") {
	everything <- sort(getNamespaceExports("survSL"))
	if(what == "both") {
		message("All prediction algorithm wrappers in SuperLearner:\n")
		print(everything[grepl(pattern="^survSL", everything)])
		message("\nAll screening algorithm wrappers in SuperLearner:\n")
		print("All")
		print(everything[grepl(pattern="screen", everything)])
	} else if(what == "SL") {
		message("All prediction algorithm wrappers in SuperLearner:\n")
		print(everything[grepl(pattern="^survSL", everything)])
	} else if(what == "survSL") {
		message("All prediction algorithm wrappers in survSL:\n")
		print(everything[grepl(pattern="^survSL", everything)])
	} else if(what == "screen") {
		message("All screening algorithm wrappers in SuperLearner:\n")
		print("All")
		print(everything[grepl(pattern="screen", everything)])
	} else if(what == 'method') {
	  message("All methods in SuperLearner package:\n")
		print(everything[grepl(pattern="^method", everything)])
	} else {
		message("All functions in SuperLearner:\n")
		print(everything)
	}
	invisible(everything)
}
