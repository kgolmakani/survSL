# Wrapper for coxph

survSL.coxph <- function(Y, X, newX, family, obsWeights, model = TRUE, ...) {
	requireNamespace('survival')
  # X must be a dataframe, not a matrix.
  if (is.matrix(X)) {
    X = as.data.frame(X) # change to model.matrix?
  }

  fit.coxph <- survival::coxph(Y ~ ., data = X, weights = obsWeights, model = model)

  # newX must be a dataframe, not a matrix.
  if (is.matrix(newX)) {
    newX = as.data.frame(newX)
  }

  pred <- as.numeric(predict(fit.coxph, newdata = newX, type = "lp"))  # remove the names with as.numeric
  fit <- list(object = fit.coxph)
  class(fit) <- "survSL.coxph"
  out <- list(pred = pred, fit = fit)
  return(out)
}


predict.survSL.coxph <- function(object, newdata, ...) {
	requireNamespace('survival')
  # newdata must be a dataframe, not a matrix.
  if (is.matrix(newdata)) {
    newdata = as.data.frame(newdata)
  }
  pred <- as.numeric(predict(object = object$object, newdata = newdata, type = "lp"))
  pred
}

survSL.coxph.interaction <- function(Y, X, newX, obsWeights, ...) {
	requireNamespace('survival')
  # X must be a dataframe, not a matrix.
  if (is.matrix(X)) {
    X = as.data.frame(X)
  }

  fit.coxph <- survival::coxph(Y ~ .^2, data = X,weights = obsWeights)

  # newX must be a dataframe, not a matrix.
  if (is.matrix(newX)) {
    newX = as.data.frame(newX)
  }

  pred <- as.numeric(predict(fit.coxph, newdata = newX, type = "lp"))
  fit <- list(object = fit.coxph)
  class(fit) <- "survSL.coxph"
  out <- list(pred = pred, fit = fit)
  return(out)
}
