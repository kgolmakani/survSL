# outline for SuperLearner methods
# these should always have class 'SL.method'
#
# The SuperLearner method is a coupling of the estimation algorithm for the algorithm weights (coefficients) and the model to combine the algorithms
#
# 2 parts need to be included:
#   1) compute coefficients
#   2) compute predictions

method.template <- function() {
  out <- list(
  # require allows you to pass a character vector with required packages
  # use NULL if no required packages
  require = NULL,
  # computeCoef is a function that returns a list with three elements:
  # 1) coef: the weights (coefficients) for each algorithm
  # 2) cvRisk: the V-fold CV risk for each algorithm
  # 3) optimizer: (optional) the result object from the optimization of the weights.
  computeCoef = function(Z, Y, libraryNames, obsWeights, control, verbose, ...) {
    cvRisk <- numeric()
    coef <- numeric()
    out <- list(cvRisk = cvRisk, coef = coef, optimizer = NULL)
    return(out)
  },
  # computePred is a function that takes the weights and the predicted values from each algorithm in the library and combines them based on the model to output the super learner predicted values
  computePred = function(predY, coef, control, ...) {
    out <- crossprod(t(predY), coef)
    return(out)
  }
  )
  invisible(out)
}

write.method.template <- function(file = '', ...) {
  cat('method.template <- function() {\n  out <- list(\n    # require allows you to pass a character vector with required packages\n    # use NULL if no required packages\n    require = NULL,\n\n    # computeCoef is a function that returns a list with two elements:\n    # 1) coef: the weights (coefficients) for each algorithm\n    # 2) cvRisk: the V-fold CV risk for each algorithm\n    computeCoef = function(Z, Y, libraryNames, obsWeights, control, verbose, ...) {\n      cvRisk <- numeric()\n      coef <- numeric()\n      out <- list(cvRisk = cvRisk, coef = coef)\n      return(out)\n    },\n\n    # computePred is a function that takes the weights and the predicted values\n    # from each algorithm in the library and combines them based on the model to\n    # output the super learner predicted values\n    computePred = function(predY, coef, control, ...) {\n      out <- crossprod(t(predY), coef)\n      return(out)\n    }\n    )\n    invisible(out)\n  }', file = file, ...)
}

# examples:
method.convex1 <- function() {
  out <- list(
    require = NULL,
    computeCoef = function(Z, Y, libraryNames, obsWeights, control, verbose, ...) {
      # compute cvRisk
      cvRisk <- apply(Z, 2, function(x) concordance(survival::coxph(Y ~ x))$concordance) # should this be replaced with a log-likelihood?
      names(cvRisk) <- libraryNames

      # compute coef
      .convex.cox <- function(Y, Z, iter.max = 100, eps = 0.000001, toler = 0.000001){
  		iter = 1
  		status <- event_Surv(Y)
		time <- time_Surv(Y)
  		censor.indx = which(status == 0)
  		failure.indx = which(status == 1) # what about other values, should add some checks?
  		censor.Z = Z[censor.indx, , drop = FALSE]
  		failure.Z = Z[failure.indx, , drop = FALSE]
  		n = length(Y)
  		q = ncol(Z)
  		t = sort(unique(time[failure.indx]))  # unique failure times in increasing order
  		m = length(unique(t)) 
  		D = lapply(1:m, function(i) which(time == t[i] & status==1))
  		d = sapply(D, length)
  		R = lapply(1:m, function(i) which(time >= t[i]))
  		C = lapply(1:n, function(i) which(t < time[i]))
  		l = function(beta){
    		(sum(sapply(1:m, function(i) sum(beta * Z[D[[i]], ]) - d[i]*
                  log(sum(exp(beta*Z[R[[i]], , drop=FALSE]))))))
  		}
  
  beta.tilda = rep(0, q) # start at 0 or equal weight?
  eta.tilda = beta.tilda %*% t(Z)
  
  while(iter < iter.max){
    beta_old = beta.tilda
    w = -sapply(1:n, function(i) 
      if(length(C[[i]])>0){
        sum(sapply(C[[i]], function(k) {
          (exp(eta.tilda[i])*sum(exp(eta.tilda[R[[k]]])) - 
             exp(eta.tilda[i])^2)*d[k] / sum(exp(eta.tilda[R[[k]]]))^2
        }))
      } else{0}
    )
    
    z = sapply(1:n, function(i) 
      if(length(C[[i]])>0){
        eta.tilda[i] - 1/w[i]*(status[i] - 
                                 exp(eta.tilda[i])*sum(sapply(C[[i]], function(k){
                                   d[k]/sum(exp(eta.tilda[R[[k]]]))
                                 })) )
      } else {0} 
      
    )      
    
    beta.hat = rep(0, q) #initialize beta.hat
    for (k in 1:q){
      if (k == 1){
        beta = beta.tilda
      } else {
        beta = c(beta.hat[1:(k-1)], beta.tilda[k:q])
      }
      numerator = as.vector((w*(z-rowSums(sweep(Z[, -k, drop = FALSE], 2, beta[-k], FUN='*')))) %*% Z[ , k, drop=FALSE])
      denominator = w %*% Z[, k, drop=FALSE]^2
      if(is.na(numerator)| is.na(denominator)){
        beta.hat[k] = 0.001
      }
      else{
        b = numerator/denominator
        beta.hat[k] = ifelse(b < 0, 0.001, b)
      }
    }
    beta.tilda = beta.hat/sum(beta.hat)
    eta.tilda = beta.tilda %*% t(Z)
    relative_diff = (abs(l(beta.tilda) - l(beta_old))/(abs(l(beta_old)) + eps))
    if (relative_diff < toler)
      break
    iter = iter + 1
    if (iter == iter.max ) {
    	if(verbose) {
    		message(paste('WARNING: algorithm did not converge in', iter.max, 'iterations.'))    		
    	}
    }

  }
  beta.tilda = ifelse(beta.tilda < 0.001, 0, beta.tilda) # extra regularization for small coefficient estimates
  return (list(eta = eta.tilda, iter = iter, init = beta.hat, coef = beta.tilda, coef_old = beta_old, diff = relative_diff))
}
	  
  fit.convex.cox <- .convex.cox(Y = Y, Z = Z)

  out <- list(cvRisk = cvRisk, coef = fit.convex.cox$coef, optimizer = fit.convex.cox)
     return(out)
  },

    computePred = function(predY, coef, ...) {
      if (sum(coef != 0) == 0) {
        stop("All metalearner coefficients are zero, cannot compute prediction.")
      }
      # Restrict crossproduct to learners with non-zero coefficients.
      out <- crossprod(t(predY[, coef != 0, drop = FALSE]), coef[coef != 0])
      return(out)
    }
  )
  invisible(out)
}



method.convex2 <- function() {
  out <- list(
    require = NULL,
    computeCoef = function(Z, Y, libraryNames, obsWeights, control, verbose, ...) {
      # compute cvRisk
      cvRisk <- apply(Z, 2, function(x) concordance(survival::coxph(Y ~ x))$concordance) # should this be replaced with a log-likelihood?
      names(cvRisk) <- libraryNames

      # compute coef
	  .convex.cox_pair = function(Y, Z, iter.max = 100){
  eps = 0.000001
  Q = ncol(Z)
  cor_mat = abs(cor(Z))
  selected = as.numeric(sort(which(cor_mat == min(cor_mat), arr.ind = TRUE)[1,]))
  Orig.Z = Z
  Z.bar = Z[, -selected]
  Z = Z[, selected]  
  status <- event_Surv(Y)
  time <- time_Surv(Y)
  censor.indx = which(status == 0)
  failure.indx = which(status == 1)
  failure.Z = Z[failure.indx, , drop = FALSE]
  n = length(Y)  
  q = ncol(Z)
  t = sort(unique(time[failure.indx]))  # unique failure times in increasing order
  m = length(unique(time[failure.indx])) 
  D = lapply(1:m, function(i) which(time == t[i] & status == 1))
  d = sapply(D, length)
  R = lapply(1:m, function(i) which(time >= t[i]))
  C = lapply(1:n, function(i) which(t < time[i]))
  l = function(beta){
    (sum(sapply(1:m, function(i) sum(beta * Z[D[[i]], ]) - d[i]*
                  log(sum(exp(beta*Z[R[[i]], , drop=FALSE]))))))
  }
  
  # initialize beta.tilda and eta.tilda
  beta.tilda = c(0,1)
  eta.tilda = beta.tilda %*% t(Z)
  
  beta.sequence = c()
  selected.sequence = selected
  
  for (ii in seq(Q-1)){
    iter = 1
    while(iter < iter.max){
      beta_old = beta.tilda
      w = -sapply(1:n, function(i) 
        if(length(C[[i]])>0){
          sum(sapply(C[[i]], function(k) {
            (exp(eta.tilda[i])*sum(exp(eta.tilda[R[[k]]])) - 
               exp(eta.tilda[i])^2)*d[k] / sum(exp(eta.tilda[R[[k]]]))^2
          }))
        } else{0}
      )
      
      z = sapply(1:n, function(i) 
        
        if(length(C[[i]])>0){
          eta.tilda[i] - 1/w[i]*(status[i] - 
                                   exp(eta.tilda[i])*sum(sapply(C[[i]], function(k){
                                     d[k]/sum(exp(eta.tilda[R[[k]]]))
                                   })) )
        } else {0} 
        
      )      
      
      if (isTRUE(all.equal(Z[,1],Z[,2]))){
        beta1.hat =0.001
      } else {
        numerator = sum(w*(Z[, 1] - Z[, 2])*(z - Z[,2]))
        denominator = sum(w*(Z[, 1] - Z[, 2])^2)
        beta1.hat = numerator/denominator
      }
      
      if (beta1.hat >0 & beta1.hat<1)
        beta1.tilda = beta1.hat
      
      if (beta1.hat < 0)
        beta1.tilda = 0.001
      
      if(beta1.hat > 1)
        beta1.tilda = 0.999
      
      
      beta2.tilda = 1 - beta1.tilda
      beta.tilda = c(beta1.tilda, beta2.tilda)
      eta.tilda = Z %*% beta.tilda
      
      relative_diff = (abs(l(beta.tilda) - l(beta_old))/(abs(l(beta_old)) + eps))
      if (relative_diff<0.000001)
        break
      
      iter = iter + 1
      if (iter == iter.max )
        message(paste('WARNING: algorithm did not converge in', 
                      iter.max, 'iterations.'))
    }
    
    ii = ii + 1
    selected = which.min(abs(cor(eta.tilda, Z.bar)))
    selected.sequence = c(selected.sequence, selected)
    beta.sequence = c(beta.sequence, beta.tilda)
    
    Z = matrix(c(eta.tilda, Z.bar[, selected]), ncol=2)
    Z.bar = Z.bar[, -selected, drop=FALSE]
  }
  
  index = seq(Q)
  index2 = selected.sequence[1:2]
  index = index[-index2]
  for (x in selected.sequence[3:Q]){
    index2 = c(index2, index[x])
    index = index[-x]
  }
  
  beta = rep(0,Q)
  beta[1] = beta.sequence[1]*prod(beta.sequence[seq(3, 2*Q-3,2)])
  beta[Q] = beta.sequence[length(beta.sequence)]
  for (i in 2:(Q-1)){
    beta[i] = beta.sequence[2*(i-1)]*prod(beta.sequence[seq(2*i-1, 2*(Q-1),2)])
  }
  
  Match = match(seq(Q), index2)
  beta.tilda = beta[Match]  
  beta.tilda_new = ifelse(beta.tilda <0.0005, 0, beta.tilda)
  eta.tilda = Orig.Z %*% beta.tilda
  eta.tilda_new = Orig.Z %*% beta.tilda_new
  
  	return (list (coef = beta.tilda, coef_new = beta.tilda_new, eta = eta.tilda, eta_new = eta.tilda_new, iter=iter) )
	}
	
	fit.convex.cox_pair <- .convex.cox_pair(Y = Y, Z= Z)
  out <- list(cvRisk = cvRisk, coef = fit.convex.cox_pair$coef, optimizer = fit.convex.cox_pair)
     return(out)
  },
    computePred = function(predY, coef, ...) {
      if (sum(coef != 0) == 0) {
        stop("All metalearner coefficients are zero, cannot compute prediction.")
      }
      # Restrict crossproduct to learners with non-zero coefficients.
      out <- crossprod(t(predY[, coef != 0, drop = FALSE]), coef[coef != 0])
      return(out)
    }
  )
  invisible(out)
}
