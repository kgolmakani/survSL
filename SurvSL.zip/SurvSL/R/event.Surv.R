event_Surv <- function(x, ...) {
# Function to extract the event/status from a Surv object
    event <- switch(attr(x, "type"),
           "right"={
               temp <- x[, 2]
           },
           "counting"= {
               temp <- x[, 3]
           },
           "left" ={
               temp <- x[, 2]
           },
           "interval"= {
               temp <- x[, 3]
           },
           "mright" = { 
               temp <- x[, 2]
           },
           "mcounting"= {
               temp <- x[, 3]
           })
    names(event) <- rownames(x)
    event
}

time_Surv <- function(x, ...) {
	time <- switch(attr(x, "type"), 
	    "right" = {
	    	x[, 1]
	    },
		"counting" = {
			x[, 1:2]
		},
		"left" = {
			x[, 1]
		},
		"mstate" = {
			x[, 1]
		})
		names(time) <- rownames(x)
		time
}