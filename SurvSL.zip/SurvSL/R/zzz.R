.onAttach <- function(...) {
  packageStartupMessage('Super Learner for time to event outcomes')
  packageStartupMessage('Version: ', utils::packageDescription('survSL')$Version)
  packageStartupMessage('Package created on ', utils::packageDescription('survSL')$Date, '\n')
}
