# Elastic net Cox regression

survSL.glmboost <- function(Y, X, newX, obsWeights, id,
	mstop = 500, nu = 0.1, stopintern = FALSE,
                      ...) {
  requireNamespace('mboost')
  # X must be a matrix, should we use model.matrix or as.matrix
  # TODO: support sparse matrices.
  if (!is.matrix(X)) {
    X <- model.matrix(~ -1 + ., X)
    newX <- model.matrix(~ -1 + ., newX)
  }

  # Use CV to find optimal lambda.
  fit <- mboost::glmboost(x = X, y = Y, 
	  						 weights = obsWeights,
                             family = mboost::CoxPH(),
							 control = mboost::boost_control(mstop = mstop, nu = nu, stopintern = stopintern),
							 center = FALSE,
                             ...)

  # If we predict with the cv.glmnet object we can specify lambda using s
  pred <- predict(fit, newdata = newX, type = "link")

  fit <- list(object = fit)
  class(fit) <- "survSL.glmboost"

  out <- list(pred = pred, fit = fit)
  return(out)
}

predict.survSL.glmboost <- function(object, newdata, ...) {
  requireNamespace('mboost')
  # TODO: support sparse matrices.
  # if fit with a matrix, must predict with a matrix as well
  # should add a check for the columns matching, will breask if factor variables with different levels
  if (!is.matrix(newdata)) {
    newdata <- model.matrix(~ -1 + ., newdata)
  }
  pred <- predict(object$object, newdata = newdata, type = "link")
  return(pred)
}
