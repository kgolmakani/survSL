# control functions for SuperLearner()
# 
# Created by Eric Polley on 2011-01-03.
# 
survSL.control <- function(saveFitLibrary = TRUE) {
	# add other control parameters here
  list(saveFitLibrary = saveFitLibrary)
}

survSL.CV.control <- function(V = 10L, shuffle = TRUE, validRows = NULL){
  # make sure V is an integer
  # what about stratify by events?
  V <- as.integer(V)
  
  # Checks for user supplied validRows is present:
  if(!is.null(validRows)) {
    if(!is.list(validRows)) {
      stop('validRows must be a list of length V containing the row numbers for the corresponding validation set')
    }
    if(!identical(V, length(validRows))) {
      stop('V and length(validRows) must be identical')
    }
  }
  list(V = V, shuffle = shuffle, validRows = validRows)
}

